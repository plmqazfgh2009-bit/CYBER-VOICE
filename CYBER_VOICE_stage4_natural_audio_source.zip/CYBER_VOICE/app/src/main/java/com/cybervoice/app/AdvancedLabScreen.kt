package com.cybervoice.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import java.io.File
import kotlin.math.max

@Composable
fun AdvancedLabScreen() {
    val context = LocalContext.current
    val engine = remember { AudioEngine(context) }
    val tools = remember { AdvancedAudioTools(context) }
    val natural = remember { NaturalAudioProcessor(context) }
    var selected by remember { mutableStateOf<File?>(null) }
    var referenceFile by remember { mutableStateOf<File?>(null) }
    var analysisText by remember { mutableStateOf("لم يتم تحليل أي ملف بعد") }
    var assistantText by remember { mutableStateOf("حلّل ملف WAV للحصول على توصيات") }
    var deviceText by remember { mutableStateOf("لم يتم فحص الجهاز بعد") }
    var original by remember { mutableStateOf<File?>(null) }
    val tracks = remember { mutableStateListOf<File>() }
    val undo = remember { mutableStateListOf<File>() }
    val redo = remember { mutableStateListOf<File>() }
    var preset by remember { mutableIntStateOf(0) }
    var targetRmsDbfs by remember { mutableFloatStateOf(-18f) }
    var live by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("استوديو الأدوات المتقدمة جاهز") }
    var presetName by remember { mutableStateOf("") }
    var profileName by remember { mutableStateOf("") }
    var transcription by remember { mutableStateOf("") }
    var spectrum by remember { mutableStateOf(List(32) { 0f }) }
    var latencyInfo by remember { mutableStateOf("لم يتم إجراء الفحص بعد") }
    var savedPresets by remember { mutableStateOf(tools.loadNamedSettings("preset")) }
    var savedPresetTargets by remember { mutableStateOf(tools.loadNamedSettings("presetTarget")) }
    var savedProfiles by remember { mutableStateOf(tools.loadNamedSettings("profile")) }
    var savedProfileTargets by remember { mutableStateOf(tools.loadNamedSettings("profileTarget")) }

    fun snapshot() {
        selected?.let { f ->
            val copy = File(context.cacheDir, "undo_${System.currentTimeMillis()}_${f.name}")
            f.copyTo(copy, overwrite = true); undo.add(copy); redo.clear()
            while (undo.size > 12) undo.removeAt(0)
        }
    }
    fun share(file: File, telegramOnly: Boolean) {
        try {
            val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = if (file.extension.equals("zip", true)) "application/zip" else "audio/*"
                putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            if (telegramOnly) {
                intent.setPackage("org.telegram.messenger")
                try { context.startActivity(intent) } catch (_: Exception) {
                    intent.setPackage(null); context.startActivity(Intent.createChooser(intent, "مشاركة الملف"))
                }
            } else context.startActivity(Intent.createChooser(intent, "مشاركة الملف"))
            status = if (telegramOnly) "تم فتح مشاركة Telegram إذا كان مثبتاً" else "تم فتح قائمة المشاركة"
        } catch (e: Exception) { status = "تعذرت المشاركة: ${e.message}" }
    }
    fun edit(action: () -> File) {
        try { if (original == null) original = selected; snapshot(); selected = action(); status = "اكتملت المعالجة وحُفظت نسخة جديدة" }
        catch (e: Exception) { status = "تعذر التنفيذ: ${e.message}" }
    }

    val importOne = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) try { selected = engine.importUri(uri); status = "تم استيراد ${selected?.name}" } catch (e: Exception) { status = e.message ?: "فشل الاستيراد" }
    }
    val importReference = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) try { referenceFile = engine.importUri(uri); status = "تم استيراد المرجع: ${referenceFile?.name}" } catch (e: Exception) { status = e.message ?: "فشل استيراد المرجع" }
    }
    val importMany = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { uri -> try { tracks.add(engine.importUri(uri)) } catch (_: Exception) {} }
        status = "تمت إضافة ${tracks.size} مسارات للمزج"
    }
    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val words = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
        if (!words.isNullOrEmpty()) { transcription = words.joinToString(" "); status = "اكتمل التفريغ الصوتي بواسطة خدمة التعرف المتاحة بالجهاز" }
        else status = "لم يرجع محرك التعرف نصاً"
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) try { engine.startLiveMonitor(preset); live = true; status = "المراقبة المباشرة تعمل — استخدم سماعات" } catch (e: Exception) { status = e.message ?: "تعذر تشغيل المراقبة" }
        else status = "يجب السماح باستخدام المايكروفون"
    }

    LaunchedEffect(preset, live) { if (live) engine.updateLivePreset(preset) }
    DisposableEffect(Unit) { onDispose { engine.stopLiveMonitor() } }

    Column(Modifier.fillMaxSize().background(Bg).padding(horizontal = 16.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeading("CYBER AUDIO LAB", "أدوات المزج والمعالجة والتحليل")
        Text(status, color = Muted, fontSize = 11.sp)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                LabCard("ملف العمل", "اختيار ملف ومقارنة النسخة الأصلية بالمعدّلة") {
                    Text(selected?.name ?: "لم يتم اختيار ملف WAV", color = Color.White, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { importOne.launch(arrayOf("audio/*")) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.FileOpen, null); Text("استيراد") }
                        OutlinedButton(onClick = { selected?.let { try { engine.play(it); status = "تشغيل النسخة الحالية" } catch (e: Exception) { status = e.message ?: "تعذر التشغيل" } } }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.PlayArrow, null); Text("تشغيل") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { original?.let { engine.play(it); status = "تشغيل Original" } ?: run { status = "لا توجد نسخة أصلية محفوظة" } }, modifier = Modifier.weight(1f)) { Text("A · Original") }
                        OutlinedButton(onClick = { selected?.let { engine.play(it); status = "تشغيل Modified" } }, modifier = Modifier.weight(1f)) { Text("B · Modified") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { if (undo.isNotEmpty()) { selected?.let { redo.add(it) }; selected = undo.removeAt(undo.lastIndex); status = "تم التراجع" } else status = "ماكو خطوة للتراجع" }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Undo, null); Text("Undo") }
                        OutlinedButton(onClick = { if (redo.isNotEmpty()) { selected?.let { undo.add(it) }; selected = redo.removeAt(redo.lastIndex); status = "تمت إعادة الخطوة" } else status = "ماكو خطوة للإعادة" }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Redo, null); Text("Redo") }
                    }
                }
            }
            item {
                LabCard("Live Voice Effects", "معالجة مباشرة من المايك إلى السماعة") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Natural", "Warm", "Bright", "Clear").forEachIndexed { i, label ->
                            FilterChip(selected = preset == i, onClick = { preset = i }, label = { Text(label, fontSize = 10.sp) })
                        }
                    }
                    Button(onClick = {
                        if (live) { engine.stopLiveMonitor(); live = false; status = "توقفت المراقبة المباشرة" }
                        else if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            try { engine.startLiveMonitor(preset); live = true; status = "Oboe Live يعمل — يفضّل استخدام سماعات" } catch (e: Exception) { status = e.message ?: "تعذر التشغيل" }
                        } else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = if (live) Color(0xFF304255) else Cyan, contentColor = if (live) Color.White else Bg)) {
                        Icon(if (live) Icons.Default.Stop else Icons.Default.Mic, null); Spacer(Modifier.width(8.dp)); Text(if (live) "إيقاف التأثير المباشر" else "تشغيل التأثير المباشر")
                    }
                    Text("مسار Oboe أصلي منخفض التأخير. استخدم سماعات لتجنب الصفير. لا يتحكم بمكالمات الهاتف أو التطبيقات الأخرى.", color = Muted, fontSize = 10.sp)
                }
            }
            item {
                LabCard("Multi-Track Studio", "مزج مسارات WAV أحادية بنفس معدل العينة") {
                    OutlinedButton(onClick = { importMany.launch(arrayOf("audio/wav", "audio/*")) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.LibraryMusic, null); Text("إضافة مسارات للمشروع (${tracks.size})") }
                    tracks.forEach { Text("• ${it.name}", color = Muted, fontSize = 10.sp) }
                    Button(onClick = { try { selected = tools.mixWav(tracks, tracks.map { 0.62f }); original = null; status = "تم مزج المسارات بملف WAV جديد" } catch (e: Exception) { status = e.message ?: "فشل المزج" } }, enabled = tracks.size >= 2, modifier = Modifier.fillMaxWidth()) { Text("Mix Tracks") }
                }
            }
            item {
                LabCard("معالجة ذكية محلية", "أدوات DSP وليست نماذج AI عصبية") {
                    Button(onClick = { selected?.let { f -> if (original == null) original = f; edit { engine.applyBasicDsp(f, preset) } } ?: run { status = "استورد WAV أولاً" } }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.AutoFixHigh, null); Text("تطبيق Voice Enhancement DSP") }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { selected?.let { f -> if (original == null) original = f; edit { tools.removeSilence(f) } } ?: run { status = "استورد WAV أولاً" } }, modifier = Modifier.weight(1f)) { Text("إزالة الصمت") }
                        OutlinedButton(onClick = { selected?.let { f -> if (original == null) original = f; edit { tools.repair(f, engine) } } ?: run { status = "استورد WAV أولاً" } }, modifier = Modifier.weight(1f)) { Text("Audio Repair") }
                    }
                    OutlinedButton(onClick = { selected?.let { f -> if (original == null) original = f; edit { engine.applyBasicDsp(f, 3) }; status = "تم تطبيق Voice Focus تقريبي؛ ليس فصل مسارات AI" } ?: run { status = "استورد WAV أولاً" } }, modifier = Modifier.fillMaxWidth()) { Text("Voice Focus / Vocal Emphasis") }
                    OutlinedButton(onClick = {
                        val wavs = engine.listAudio().filter { it.extension.equals("wav", true) }
                        var done = 0
                        wavs.forEach { f -> try { engine.applyBasicDsp(f, preset); done++ } catch (_: Exception) {} }
                        status = "Batch Processing: تمت معالجة $done من ${wavs.size} ملفات WAV"
                    }, modifier = Modifier.fillMaxWidth()) { Text("Batch Process كل ملفات WAV") }
                }
            }
            item {
                LabCard("Naturalness Analyzer", "قياسات WAV: RMS وPeak وClipping والضوضاء المقدّرة") {
                    Button(onClick = {
                        selected?.let { f -> try {
                            val r = natural.analyze(f)
                            analysisText = "المدة: ${"%.2f".format(r.durationSeconds)} s · ${r.sampleRate} Hz\nRMS: ${"%.1f".format(r.rmsDbfs)} dBFS · Peak: ${"%.1f".format(r.samplePeakDbfs)} dBFS\nTrue Peak تقديري: ${"%.1f".format(r.estimatedTruePeakDbfs)} dBFS\nClipping: ${"%.3f".format(r.clippingPercent)}% · Noise Floor تقديري: ${"%.1f".format(r.estimatedNoiseFloorDbfs)} dBFS\nCrest: ${"%.1f".format(r.crestFactorDb)} dB · Centroid: ${"%.0f".format(r.spectralCentroidHz)} Hz"
                            assistantText = natural.assistantAdvice(f)
                            status = "اكتمل تحليل التسجيل"
                        } catch (e: Exception) { status = e.message ?: "تعذر التحليل" } } ?: run { status = "استورد ملف WAV أحادي أولاً" }
                    }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.GraphicEq, null); Text("Analyze Audio") }
                    Text(analysisText, color = Color.White, fontSize = 11.sp)
                }
            }
            item {
                LabCard("Natural Audio Processing", "Smart EQ · Adaptive Noise · Loudness · Repair") {
                    OutlinedButton(onClick = { selected?.let { f -> edit { natural.smartAutoEq(f) } } ?: run { status = "استورد WAV أحادي أولاً" } }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Tune, null); Text("Smart Auto EQ") }
                    OutlinedButton(onClick = { selected?.let { f -> edit { natural.adaptiveNoiseControl(f) } } ?: run { status = "استورد WAV أحادي أولاً" } }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.GraphicEq, null); Text("Adaptive Noise Control") }
                    Text("Target RMS: ${targetRmsDbfs.toInt()} dBFS", color = Color.White, fontSize = 11.sp)
                    Slider(value = targetRmsDbfs, onValueChange = { targetRmsDbfs = it }, valueRange = -30f..-12f, steps = 17)
                    OutlinedButton(onClick = { selected?.let { f -> edit { natural.normalizeLoudness(f, targetRmsDbfs.toDouble()) } } ?: run { status = "استورد WAV أحادي أولاً" } }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.VolumeUp, null); Text("Loudness Intelligence · RMS dBFS") }
                    OutlinedButton(onClick = { selected?.let { f -> edit { natural.advancedRepair(f) } } ?: run { status = "استورد WAV أحادي أولاً" } }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Build, null); Text("Advanced Audio Repair") }
                    Text("هذه أدوات DSP محلية. Loudness هنا يعتمد RMS dBFS وليس معيار LUFS، وإصلاح clipping الشديد غير مضمون.", color = Muted, fontSize = 10.sp)
                }
            }
            item {
                LabCard("CYBER AI Assistant", "توصيات محلية مبنية على قياسات التسجيل") {
                    Button(onClick = { selected?.let { f -> try { assistantText = natural.assistantAdvice(f); status = "تم إعداد التوصيات" } catch (e: Exception) { status = e.message ?: "تعذر التحليل" } } ?: run { status = "استورد WAV أحادي أولاً" } }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.AutoFixHigh, null); Text("تحليل واقتراح إعدادات") }
                    Text(assistantText, color = Color.White, fontSize = 11.sp)
                    Text("مساعد قواعد محلي في هذه النسخة، وليس نموذجاً عصبياً أو خدمة AI سحابية.", color = Muted, fontSize = 10.sp)
                }
            }
            item {
                LabCard("Reference Comparison", "مقارنة قياسات التسجيل بمرجع تملكه أو لديك إذن باستخدامه") {
                    OutlinedButton(onClick = { importReference.launch(arrayOf("audio/wav")) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.FolderOpen, null); Text(referenceFile?.name ?: "اختيار ملف مرجعي WAV") }
                    Button(onClick = { val a = referenceFile; val b = selected; if (a != null && b != null) try {
                        val c = natural.compare(a, b)
                        analysisText = "فرق RMS: ${"%.2f".format(c.rmsDifferenceDb)} dB · فرق Peak: ${"%.2f".format(c.peakDifferenceDb)} dB · فرق Centroid: ${"%.0f".format(c.centroidDifferenceHz)} Hz"
                        status = "اكتملت مقارنة المرجع"
                    } catch (e: Exception) { status = e.message ?: "فشلت المقارنة" } else status = "اختار الملف المرجعي وملف العمل أولاً" }, enabled = referenceFile != null && selected != null, modifier = Modifier.fillMaxWidth()) { Text("Compare Reference") }
                }
            }
            item {
                LabCard("Device Optimization", "معلومات موارد الجهاز والحالة الحرارية") {
                    Button(onClick = { try { val d = natural.deviceReport(); deviceText = "CPU Cores: ${d.processors} · RAM: ${d.usedMemoryMb}/${d.totalMemoryMb} MB · Thermal: ${d.thermalStatus}"; status = "اكتمل فحص موارد الجهاز" } catch (e: Exception) { status = e.message ?: "تعذر فحص الجهاز" } }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Settings, null); Text("فحص موارد الجهاز") }
                    Text(deviceText, color = Cyan, fontSize = 11.sp)
                }
            }
            item {
                LabCard("Spectrum Analyzer", "تحليل ترددي للملف المحدد") {
                    OutlinedButton(onClick = { selected?.let { try { spectrum = tools.spectrum(it); status = "تم تحليل الطيف" } catch (e: Exception) { status = e.message ?: "تعذر التحليل" } } ?: run { status = "اختار ملف WAV أولاً" } }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.GraphicEq, null); Text("تحليل الترددات") }
                    Canvas(Modifier.fillMaxWidth().height(105.dp).background(Color(0xFF08121E), RoundedCornerShape(12.dp)).padding(8.dp)) {
                        val gap = 3.dp.toPx(); val count = spectrum.size.coerceAtLeast(1); val barW = (size.width - gap * (count - 1)) / count
                        spectrum.forEachIndexed { i, v ->
                            val h = size.height * v.coerceIn(0.02f, 1f)
                            drawRect(Cyan, androidx.compose.ui.geometry.Offset(i * (barW + gap), size.height - h), androidx.compose.ui.geometry.Size(barW, h))
                        }
                    }
                }
            }
            item {
                LabCard("Presets & Voice Profiles", "حفظ إعداداتك وتسميتها محلياً") {
                    OutlinedTextField(value = presetName, onValueChange = { presetName = it }, label = { Text("اسم Preset جديد") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Button(onClick = { if (presetName.isNotBlank()) { val key = presetName.trim(); tools.saveNamedSetting("preset", key, preset); tools.saveNamedSetting("presetTarget", key, targetRmsDbfs.toInt()); savedPresets = tools.loadNamedSettings("preset"); savedPresetTargets = tools.loadNamedSettings("presetTarget"); presetName = ""; status = "تم حفظ إعدادات المعالجة" } }, modifier = Modifier.fillMaxWidth()) { Text("حفظ الإعداد") }
                    savedPresets.forEach { (name, value) -> TextButton(onClick = { preset = value.coerceIn(0, 3); targetRmsDbfs = (savedPresetTargets[name] ?: -18).toFloat().coerceIn(-30f, -12f); status = "تم تحميل $name" }) { Text("Preset: $name") } }
                    OutlinedTextField(value = profileName, onValueChange = { profileName = it }, label = { Text("اسم Voice Profile") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Button(onClick = { if (profileName.isNotBlank()) { val key = profileName.trim(); tools.saveNamedSetting("profile", key, preset); tools.saveNamedSetting("profileTarget", key, targetRmsDbfs.toInt()); savedProfiles = tools.loadNamedSettings("profile"); savedProfileTargets = tools.loadNamedSettings("profileTarget"); profileName = ""; status = "تم حفظ Voice Profile وإعداداته" } }, modifier = Modifier.fillMaxWidth()) { Text("حفظ Voice Profile") }
                    savedProfiles.forEach { (name, value) -> TextButton(onClick = { preset = value.coerceIn(0, 3); targetRmsDbfs = (savedProfileTargets[name] ?: -18).toFloat().coerceIn(-30f, -12f); status = "تم تحميل Profile: $name" }) { Text("Profile: $name") } }
                }
            }
            item {
                LabCard("AI Transcription", "استخدام خدمة التعرف على الكلام المتاحة في Android") {
                    Button(onClick = {
                        try { val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-IQ").putExtra(RecognizerIntent.EXTRA_PROMPT, "تحدث لتحويل كلامك إلى نص"); speech.launch(i) }
                        catch (_: Exception) { status = "لا توجد خدمة تعرف صوت مثبتة أو متاحة" }
                    }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.RecordVoiceOver, null); Text("بدء التفريغ الصوتي") }
                    if (transcription.isNotBlank()) Text(transcription, color = Color.White, fontSize = 12.sp)
                    Text("هذا يحوّل الكلام الحي إلى نص عبر خدمة الجهاز؛ تفريغ ملف صوتي محفوظ يحتاج محرك ASR يدعم إدخال الملفات.", color = Muted, fontSize = 10.sp)
                }
            }
            item {
                LabCard("Backup & Sharing", "نسخ احتياطي ومشاركة الملفات") {
                    Button(onClick = { try { val backup = tools.createBackup(engine.listAudio()); share(backup, false) } catch (e: Exception) { status = e.message ?: "فشل النسخ الاحتياطي" } }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Backup, null); Text("إنشاء Backup ومشاركته") }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { selected?.let { share(it, false) } ?: run { status = "اختار ملف أولاً" } }, modifier = Modifier.weight(1f)) { Text("مشاركة") }
                        OutlinedButton(onClick = { selected?.let { share(it, true) } ?: run { status = "اختار ملف أولاً" } }, modifier = Modifier.weight(1f)) { Text("إلى Telegram") }
                    }
                }
            }
            item {
                LabCard("Oboe Diagnostics", "مؤشرات المسار الصوتي الأصلي أثناء التشغيل المباشر") {
                    Button(onClick = {
                        val m = engine.liveMetrics()
                        latencyInfo = if (m.size >= 5) "Oboe ${m[0].toInt()} Hz · Input burst ${m[1].toInt()} frames · Output burst ${m[2].toInt()} frames · Underrun samples ${m[3].toLong()} · Xruns ${m[4].toInt()}" else "شغّل Oboe Live أولاً لقراءة مؤشرات المسار الفعلي. لا يتم عرض زمن RTT غير مقاس."
                        status = "اكتمل فحص مؤشرات Oboe المتاحة"
                    }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Speed, null); Text("فحص جودة الصوت والتأخير") }
                    Text(latencyInfo, color = Cyan, fontSize = 11.sp)
                    Text("Burst وXrun مؤشرات من Oboe وليست قياساً كاملاً لتأخير المايك إلى السماعة. WebRTC غير مفعّل في هذا الإصدار.", color = Muted, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
private fun LabCard(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).border(1.dp, Cyan.copy(alpha = .22f), RoundedCornerShape(18.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Text(title, color = Cyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(subtitle, color = Muted, fontSize = 10.sp)
        content()
    }
}
