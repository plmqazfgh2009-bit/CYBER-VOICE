package com.cybervoice.app

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sqrt

/** Local PCM/WAV tools. These are deterministic DSP utilities, not neural AI models. */
class AdvancedAudioTools(private val context: Context) {
    data class Wav(val samples: ShortArray, val sampleRate: Int, val channels: Int)

    fun readWav(file: File): Wav {
        val b = file.readBytes()
        require(b.size > 44 && String(b, 0, 4) == "RIFF" && String(b, 8, 4) == "WAVE") { "حالياً نحتاج WAV PCM صالح" }
        val channels = u16(b, 22).coerceIn(1, 2)
        val rate = i32(b, 24).coerceAtLeast(8000)
        val bits = u16(b, 34)
        require(bits == 16) { "الملف لازم يكون PCM 16-bit" }
        val (dataAt, dataLength) = findDataChunkInfo(b)
        val size = minOf(dataLength, b.size - dataAt).coerceAtLeast(0) / 2
        val pcm = ShortArray(size) { i -> ((b[dataAt + i * 2].toInt() and 255) or (b[dataAt + i * 2 + 1].toInt() shl 8)).toShort() }
        return Wav(pcm, rate, channels)
    }

    fun writeWav(file: File, samples: ShortArray, sampleRate: Int = 48000, channels: Int = 1) {
        file.parentFile?.mkdirs()
        RandomAccessFile(file, "rw").use { r ->
            r.setLength(0); r.write(ByteArray(44))
            val bytes = ByteArray(samples.size * 2)
            samples.forEachIndexed { i, s -> bytes[i * 2] = s.toByte(); bytes[i * 2 + 1] = (s.toInt() shr 8).toByte() }
            r.write(bytes); r.seek(0)
            r.writeBytes("RIFF"); putInt(r, 36 + bytes.size); r.writeBytes("WAVEfmt "); putInt(r, 16)
            putShort(r, 1); putShort(r, channels); putInt(r, sampleRate); putInt(r, sampleRate * channels * 2)
            putShort(r, channels * 2); putShort(r, 16); r.writeBytes("data"); putInt(r, bytes.size)
        }
    }

    fun mixWav(files: List<File>, gains: List<Float>): File {
        require(files.size >= 2) { "اختار ملفين صوت على الأقل" }
        val tracks = files.map { readWav(it) }
        require(tracks.all { it.sampleRate == tracks.first().sampleRate && it.channels == 1 }) { "المزج الحالي يحتاج ملفات WAV أحادية وبنفس معدل العينة" }
        val length = tracks.maxOf { it.samples.size }
        val out = ShortArray(length)
        for (i in 0 until length) {
            var sum = 0f
            tracks.forEachIndexed { t, wav -> if (i < wav.samples.size) sum += wav.samples[i] * (gains.getOrNull(t) ?: 0.65f) }
            out[i] = sum.coerceIn(-32768f, 32767f).toInt().toShort()
        }
        val file = File(context.getExternalFilesDir(null), "CV_MIX_${System.currentTimeMillis()}.wav")
        writeWav(file, out, tracks.first().sampleRate, 1); return file
    }

    /** Removes sustained low-energy 20 ms blocks while preserving short pauses. */
    fun removeSilence(input: File, threshold: Float = 0.008f): File {
        val wav = readWav(input); val frame = (wav.sampleRate / 50).coerceAtLeast(1)
        val kept = ArrayList<Short>(wav.samples.size)
        var quietRun = 0
        for (start in wav.samples.indices step frame) {
            val end = minOf(start + frame, wav.samples.size)
            var energy = 0.0
            for (i in start until end) { val v = wav.samples[i] / 32768.0; energy += v * v }
            val rms = sqrt(energy / (end - start).coerceAtLeast(1))
            if (rms < threshold) quietRun++ else quietRun = 0
            // Keep brief pauses, discard only quiet runs longer than 350 ms.
            if (rms >= threshold || quietRun <= 17) for (i in start until end) kept.add(wav.samples[i])
        }
        val out = File(context.getExternalFilesDir(null), "CV_TRIM_${System.currentTimeMillis()}.wav")
        writeWav(out, kept.toShortArray(), wav.sampleRate, wav.channels); return out
    }

    /** A conservative local repair: interpolate isolated full-scale clicks and apply gentle DSP. */
    fun repair(input: File, engine: AudioEngine): File {
        val wav = readWav(input)
        val fixed = wav.samples.copyOf()
        for (i in 1 until fixed.lastIndex) {
            val p = fixed[i - 1].toInt(); val n = fixed[i + 1].toInt(); val c = fixed[i].toInt()
            if (kotlin.math.abs(c) > 32600 && kotlin.math.abs(p) < 18000 && kotlin.math.abs(n) < 18000) fixed[i] = ((p + n) / 2).toShort()
        }
        val temp = File(context.cacheDir, "repair_input.wav"); writeWav(temp, fixed, wav.sampleRate, wav.channels)
        return engine.applyBasicDsp(temp, 3)
    }

    /** Simple windowed DFT for a compact visual spectrum; suitable for preview, not metering certification. */
    fun spectrum(file: File, bins: Int = 32): List<Float> {
        val x = readWav(file).samples
        if (x.isEmpty()) return List(bins) { 0f }
        val n = minOf(512, x.size).coerceAtLeast(32)
        return (0 until bins).map { band ->
            val k = band + 1
            var re = 0.0; var im = 0.0
            for (i in 0 until n) {
                val window = 0.5 - 0.5 * cos(2.0 * PI * i / (n - 1))
                val angle = 2.0 * PI * k * i / n
                val v = x[i] / 32768.0 * window
                re += v * cos(angle); im -= v * kotlin.math.sin(angle)
            }
            (sqrt(re * re + im * im) / n * 5.0).toFloat().coerceIn(0f, 1f)
        }
    }

    fun saveNamedSetting(key: String, name: String, value: Int) {
        context.getSharedPreferences("cyber_voice_profiles", Context.MODE_PRIVATE).edit().putInt("$key:$name", value).apply()
    }
    fun loadNamedSettings(key: String): Map<String, Int> {
        val all = context.getSharedPreferences("cyber_voice_profiles", Context.MODE_PRIVATE).all
        return all.filterKeys { it.startsWith("$key:") }.mapKeys { it.key.removePrefix("$key:") }.mapValues { (it.value as? Int) ?: 0 }
    }

    fun createBackup(files: List<File>): File {
        val out = File(context.getExternalFilesDir(null), "CYBER_BACKUP_${System.currentTimeMillis()}.zip")
        ZipOutputStream(FileOutputStream(out)).use { zip ->
            files.filter { it.isFile && it.extension.lowercase() in setOf("wav", "m4a", "mp3", "opus", "ogg", "3gp") }.forEach { f ->
                zip.putNextEntry(ZipEntry("audio/${f.name}")); f.inputStream().use { it.copyTo(zip) }; zip.closeEntry()
            }
            val prefs = context.getSharedPreferences("cyber_voice_profiles", Context.MODE_PRIVATE).all
            zip.putNextEntry(ZipEntry("settings.txt")); zip.write(prefs.entries.joinToString("\n") { "${it.key}=${it.value}" }.toByteArray()); zip.closeEntry()
        }
        return out
    }

    private fun findDataChunkInfo(b: ByteArray): Pair<Int, Int> {
        var p = 12
        while (p + 8 <= b.size) {
            val id = String(b, p, 4)
            val len = i32(b, p + 4).coerceAtLeast(0)
            if (id == "data") return (p + 8) to len
            val next = p.toLong() + 8L + len.toLong() + (len and 1)
            if (next > b.size) break
            p = next.toInt()
        }
        require(b.size >= 44) { "ملف WAV لا يحتوي على data chunk" }
        return 44 to (b.size - 44)
    }
    private fun u16(b: ByteArray, p: Int) = (b[p].toInt() and 255) or ((b[p + 1].toInt() and 255) shl 8)
    private fun i32(b: ByteArray, p: Int) = u16(b, p) or (u16(b, p + 2) shl 16)
    private fun putInt(r: RandomAccessFile, v: Int) { repeat(4) { r.write(v ushr (it * 8) and 255) } }
    private fun putShort(r: RandomAccessFile, v: Int) { r.write(v and 255); r.write(v ushr 8 and 255) }
}
