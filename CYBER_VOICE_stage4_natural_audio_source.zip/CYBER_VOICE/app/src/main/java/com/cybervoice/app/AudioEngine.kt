package com.cybervoice.app

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.AudioTrack
import android.media.AudioAttributes
import android.media.AudioManager
import android.net.Uri
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread
import kotlin.math.max

/** PCM capture and WAV file engine. Capture is mono PCM16 at 48 kHz when supported. */
class AudioEngine(private val context: Context) {
    companion object { const val SAMPLE_RATE = 48000; init { System.loadLibrary("cyberdsp") } }
    private var recorder: AudioRecord? = null
    private var worker: Thread? = null
    private var output: File? = null
    private val running = AtomicBoolean(false)
    private val monitorRunning = AtomicBoolean(false)

    fun startRecording(preset: Int = 0): File {
        check(!running.get()) { "التسجيل شغال بالفعل" }
        check(!monitorRunning.get()) { "أوقف Live قبل بدء التسجيل" }
        val min = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        require(min > 0) { "الجهاز لا يدعم إعداد التسجيل المطلوب" }
        val bufferSize = max(min * 2, 8192)
        val source = if (android.os.Build.VERSION.SDK_INT >= 24) MediaRecorder.AudioSource.UNPROCESSED else MediaRecorder.AudioSource.MIC
        var rec = AudioRecord(source, SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize)
        if (rec.state != AudioRecord.STATE_INITIALIZED && source != MediaRecorder.AudioSource.MIC) {
            rec.release()
            rec = AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize)
        }
        check(rec.state == AudioRecord.STATE_INITIALIZED) { "تعذر تهيئة المايكروفون" }
        val file = File(context.getExternalFilesDir(null), "CYBER_${System.currentTimeMillis()}.wav")
        output = file
        recorder = rec
        running.set(true)
        rec.startRecording()
        worker = thread(name = "CyberAudioCapture") {
            RandomAccessFile(file, "rw").use { wav ->
                wav.setLength(0); wav.write(ByteArray(44))
                val buffer = ShortArray(1024)
                val floatBuffer = FloatArray(1024)
                nativeResetProcessing()
                var dataBytes = 0L
                while (running.get()) {
                    val count = rec.read(buffer, 0, buffer.size)
                    if (count > 0) {
                        for (i in 0 until count) floatBuffer[i] = buffer[i] / 32768f
                        val processed = floatBuffer.copyOf(count)
                        nativeProcess(processed, preset)
                        val bytes = ByteArray(count * 2)
                        for (i in 0 until count) { val v = (processed[i].coerceIn(-1f, 1f) * 32767f).toInt(); bytes[i*2] = v.toByte(); bytes[i*2+1] = (v shr 8).toByte() }
                        wav.write(bytes); dataBytes += bytes.size
                    }
                }
                writeWavHeader(wav, dataBytes, SAMPLE_RATE, 1, 16)
            }
        }
        return file
    }

    fun stopRecording(): File? {
        if (!running.getAndSet(false)) return output
        try { recorder?.stop() } catch (_: Exception) {}
        try { worker?.join(2500) } catch (_: InterruptedException) {}
        recorder?.release(); recorder = null; worker = null
        return output
    }


    /** True low-latency full-duplex Live path using native Oboe input/output callbacks. */
    fun startLiveMonitor(preset: Int) {
        check(!monitorRunning.get()) { "المراقبة المباشرة تعمل بالفعل" }
        check(!running.get()) { "أوقف التسجيل قبل تشغيل Live" }
        val result = nativeStartOboe(preset)
        check(result == 0) { "تعذر تشغيل Oboe: $result — تحقق من صلاحية المايك وتوافق مسار الصوت" }
        monitorRunning.set(true)
    }

    fun updateLivePreset(preset: Int) {
        if (monitorRunning.get()) nativeSetOboePreset(preset)
    }

    fun liveMetrics(): FloatArray = nativeOboeMetrics()

    fun stopLiveMonitor() {
        if (!monitorRunning.getAndSet(false)) return
        nativeStopOboe()
    }

    fun importUri(uri: Uri): File {
        val dir = File(context.getExternalFilesDir(null), "imports").apply { mkdirs() }
        val file = File(dir, "import_${System.currentTimeMillis()}_${uri.lastPathSegment?.takeLast(20) ?: "audio"}")
        context.contentResolver.openInputStream(uri).use { input -> requireNotNull(input) { "تعذر فتح الملف" }; FileOutputStream(file).use { input.copyTo(it) } }
        return file
    }

    fun listAudio(): List<File> = (context.getExternalFilesDir(null)?.walkTopDown()?.filter { it.isFile && (it.extension.lowercase() in listOf("wav", "m4a", "mp3", "opus", "ogg", "3gp")) }?.toList() ?: emptyList()).sortedByDescending { it.lastModified() }

    fun play(file: File) {
        val bytes = file.readBytes()
        if (file.extension.equals("wav", true) && bytes.size > 44) {
            val pcm = bytes.copyOfRange(44, bytes.size)
            val rate = ((bytes[24].toInt() and 255) or ((bytes[25].toInt() and 255) shl 8) or ((bytes[26].toInt() and 255) shl 16) or ((bytes[27].toInt() and 255) shl 24)).coerceAtLeast(8000)
            val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val track = AudioTrack(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build(), AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build(), max(min, pcm.size), AudioTrack.MODE_STATIC, AudioManager.AUDIO_SESSION_ID_GENERATE)
            track.write(pcm, 0, pcm.size); track.play()
            thread { try { Thread.sleep((pcm.size / 2 * 1000L / SAMPLE_RATE) + 200) } catch (_: Exception) {}; track.release() }
        } else {
            val player = android.media.MediaPlayer()
            player.setDataSource(file.absolutePath); player.setOnCompletionListener { it.release() }; player.prepare(); player.start()
        }
    }

    fun applyBasicDsp(input: File, preset: Int): File {
        require(input.extension.equals("wav", true)) { "المعالجة الحالية تدعم WAV PCM فقط" }
        val wav = AdvancedAudioTools(context).readWav(input)
        require(wav.channels == 1) { "المعالجة الأصلية تتطلب ملف WAV أحادي القناة" }
        val floats = FloatArray(wav.samples.size) { wav.samples[it] / 32768f }
        nativeResetProcessing()
        nativeProcess(floats, preset)
        val outputSamples = ShortArray(floats.size) { (floats[it].coerceIn(-1f, 1f) * 32767f).toInt().toShort() }
        val out = File(context.getExternalFilesDir(null), "CYBER_EDIT_${System.currentTimeMillis()}.wav")
        AdvancedAudioTools(context).writeWav(out, outputSamples, wav.sampleRate, 1)
        return out
    }

    private external fun nativeProcess(samples: FloatArray, preset: Int)
    private external fun nativeResetProcessing()
    private external fun nativeStartOboe(preset: Int): Int
    private external fun nativeStopOboe()
    private external fun nativeSetOboePreset(preset: Int)
    private external fun nativeOboeMetrics(): FloatArray
    private fun writeWavHeader(raf: RandomAccessFile, dataSize: Long, rate: Int, channels: Int, bits: Int) {
        raf.seek(0); raf.writeBytes("RIFF"); writeInt(raf, (36 + dataSize).toInt()); raf.writeBytes("WAVEfmt "); writeInt(raf, 16); writeShort(raf, 1); writeShort(raf, channels); writeInt(raf, rate); writeInt(raf, rate * channels * bits / 8); writeShort(raf, channels * bits / 8); writeShort(raf, bits); raf.writeBytes("data"); writeInt(raf, dataSize.toInt())
    }
    private fun writeInt(r: RandomAccessFile, v: Int) { r.write(v and 255); r.write((v shr 8) and 255); r.write((v shr 16) and 255); r.write((v shr 24) and 255) }
    private fun writeShort(r: RandomAccessFile, v: Int) { r.write(v and 255); r.write((v shr 8) and 255) }
}
