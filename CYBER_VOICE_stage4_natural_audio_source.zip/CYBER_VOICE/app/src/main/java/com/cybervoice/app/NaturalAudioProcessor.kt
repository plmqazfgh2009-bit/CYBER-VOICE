package com.cybervoice.app

import android.content.Context
import android.os.Build
import android.os.PowerManager
import android.app.ActivityManager
import java.io.File
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Deterministic local audio analysis and processing. No neural model is implied by these tools. */
class NaturalAudioProcessor(private val context: Context) {
    data class Report(
        val durationSeconds: Double,
        val sampleRate: Int,
        val rmsDbfs: Double,
        val samplePeakDbfs: Double,
        val estimatedTruePeakDbfs: Double,
        val clippingPercent: Double,
        val estimatedNoiseFloorDbfs: Double,
        val crestFactorDb: Double,
        val spectralCentroidHz: Double
    )

    data class Comparison(val rmsDifferenceDb: Double, val peakDifferenceDb: Double, val centroidDifferenceHz: Double)
    data class DeviceReport(val processors: Int, val usedMemoryMb: Long, val totalMemoryMb: Long, val thermalStatus: String)

    private fun requireMono(file: File): AdvancedAudioTools.Wav {
        val wav = AdvancedAudioTools(context).readWav(file)
        require(wav.channels == 1) { "هذه المعالجة حالياً تتطلب WAV أحادي القناة (Mono)" }
        require(wav.samples.isNotEmpty()) { "ملف الصوت فارغ" }
        return wav
    }

    fun analyze(file: File): Report {
        val wav = requireMono(file)
        val x = wav.samples
        var sum = 0.0
        var peak = 0.0
        var clipped = 0L
        var truePeak = 0.0
        for (i in x.indices) {
            val v = x[i] / 32768.0
            sum += v * v
            peak = max(peak, abs(v))
            if (abs(x[i].toInt()) >= 32760) clipped++
            if (i > 0) {
                val p = x[i - 1] / 32768.0
                for (step in 1..3) truePeak = max(truePeak, abs(p + (v - p) * (step / 4.0)))
            }
        }
        val rms = sqrt(sum / x.size)
        val block = max(1, wav.sampleRate / 50) // 20 ms blocks
        val levels = ArrayList<Double>()
        for (start in x.indices step block) {
            val end = min(x.size, start + block)
            var e = 0.0
            for (i in start until end) { val v = x[i] / 32768.0; e += v * v }
            levels += sqrt(e / (end - start).coerceAtLeast(1))
        }
        levels.sort()
        val floor = levels[(levels.size * 0.10).toInt().coerceIn(0, levels.lastIndex)]
        val centroid = spectralCentroid(x, wav.sampleRate)
        fun db(v: Double) = if (v <= 1e-9) -180.0 else 20.0 * log10(v)
        return Report(
            durationSeconds = x.size.toDouble() / wav.sampleRate,
            sampleRate = wav.sampleRate,
            rmsDbfs = db(rms),
            samplePeakDbfs = db(peak),
            estimatedTruePeakDbfs = db(truePeak),
            clippingPercent = clipped.toDouble() * 100.0 / x.size,
            estimatedNoiseFloorDbfs = db(floor),
            crestFactorDb = if (rms <= 1e-9) 0.0 else db(peak / rms),
            spectralCentroidHz = centroid
        )
    }

    /** Conservative 3-band tonal correction. Gains are limited to +/- 2.5 dB. */
    fun smartAutoEq(input: File): File {
        val wav = requireMono(input)
        val x = wav.samples
        val lowCut = onePoleCoefficient(220.0, wav.sampleRate)
        val midCut = onePoleCoefficient(3200.0, wav.sampleRate)
        var low = 0.0
        var lowEnergy = 0.0; var midEnergy = 0.0; var highEnergy = 0.0
        val lowBands = DoubleArray(x.size)
        val midBands = DoubleArray(x.size)
        val highBands = DoubleArray(x.size)
        var low2 = 0.0
        for (i in x.indices) {
            val v = x[i] / 32768.0
            low += lowCut * (v - low)
            low2 += midCut * (v - low2)
            val lo = low
            val mid = low2 - low
            val hi = v - low2
            lowBands[i] = lo; midBands[i] = mid; highBands[i] = hi
            lowEnergy += lo * lo; midEnergy += mid * mid; highEnergy += hi * hi
        }
        val count = x.size.toDouble()
        val levels = doubleArrayOf(sqrt(lowEnergy / count), sqrt(midEnergy / count), sqrt(highEnergy / count)).map { max(it, 0.0005) }
        val target = levels.sorted()[1]
        val gains = levels.map { (target / it).coerceIn(0.75, 1.33) }
        val out = ShortArray(x.size)
        for (i in out.indices) {
            val v = lowBands[i] * gains[0] + midBands[i] * gains[1] + highBands[i] * gains[2]
            out[i] = (v.coerceIn(-0.999, 0.999) * 32767.0).toInt().toShort()
        }
        return writeResult(input, out, "AUTOEQ")
    }

    /** Adaptive expander/gate based on the quiet-block floor; not neural noise separation. */
    fun adaptiveNoiseControl(input: File): File {
        val wav = requireMono(input)
        val x = wav.samples
        val frame = max(1, wav.sampleRate / 50)
        val rmsBlocks = ArrayList<Double>()
        for (start in x.indices step frame) {
            val end = min(x.size, start + frame)
            var e = 0.0
            for (i in start until end) { val v = x[i] / 32768.0; e += v * v }
            rmsBlocks += sqrt(e / (end - start).coerceAtLeast(1))
        }
        val sorted = rmsBlocks.sorted()
        val floor = sorted[(sorted.size * 0.20).toInt().coerceIn(0, sorted.lastIndex)]
        val threshold = max(0.0025, floor * 2.2)
        val out = ShortArray(x.size)
        var envelope = 0.0
        var gain = 1.0
        for (i in x.indices) {
            val v = x[i] / 32768.0
            envelope += (if (abs(v) > envelope) 0.08 else 0.003) * (abs(v) - envelope)
            val target = if (envelope < threshold) (0.35 + 0.65 * (envelope / threshold)).coerceIn(0.35, 1.0) else 1.0
            gain += (if (target < gain) 0.018 else 0.003) * (target - gain)
            out[i] = (v * gain * 32767.0).toInt().coerceIn(-32767, 32767).toShort()
        }
        return writeResult(input, out, "NOISE")
    }

    /** RMS target normalization with a hard safety ceiling. This reports dBFS, not LUFS. */
    fun normalizeLoudness(input: File, targetRmsDbfs: Double = -18.0, ceilingDbfs: Double = -1.0): File {
        val wav = requireMono(input)
        val rms = sqrt(wav.samples.map { val v = it / 32768.0; v * v }.average())
        if (rms <= 1e-9) throw IllegalArgumentException("لا يمكن موازنة ملف صامت")
        val peak = wav.samples.maxOf { abs(it.toInt()) } / 32768.0
        val target = 10.0.pow10(targetRmsDbfs / 20.0)
        val ceiling = 10.0.pow10(ceilingDbfs / 20.0)
        val gain = min(target / rms, ceiling / max(peak, 1e-9))
        val out = ShortArray(wav.samples.size) { i -> (wav.samples[i] * gain).toInt().coerceIn(-32767, 32767).toShort() }
        return writeResult(input, out, "LOUD")
    }

    /** Repairs only isolated single-sample impulses; does not reconstruct clipped sections. */
    fun advancedRepair(input: File): File {
        val wav = requireMono(input)
        val out = wav.samples.copyOf()
        for (i in 1 until wav.samples.lastIndex) {
            val p = wav.samples[i - 1].toInt()
            val c = wav.samples[i].toInt()
            val n = wav.samples[i + 1].toInt()
            val local = (p + n) / 2
            if (abs(c - local) > 12000 && abs(p - n) < 5000 && abs(c) > 7000) {
                out[i] = local.coerceIn(-32767, 32767).toShort()
            }
        }
        return writeResult(input, out, "REPAIR")
    }

    fun compare(reference: File, processed: File): Comparison {
        val a = analyze(reference); val b = analyze(processed)
        return Comparison(b.rmsDbfs - a.rmsDbfs, b.samplePeakDbfs - a.samplePeakDbfs, b.spectralCentroidHz - a.spectralCentroidHz)
    }

    /** Transparent rule-based recommendations. A neural AI model is not bundled in this build. */
    fun assistantAdvice(file: File): String {
        val r = analyze(file)
        val advice = ArrayList<String>()
        if (r.clippingPercent > 0.01) advice += "يوجد clipping؛ جرّب Audio Repair، لكن الأجزاء المقصوصة بشدة لا يمكن استعادتها بالكامل."
        if (r.rmsDbfs < -30) advice += "مستوى التسجيل منخفض؛ جرّب Loudness Intelligence مع مراقبة حد الذروة."
        if (r.estimatedNoiseFloorDbfs > -45) advice += "مستوى الخلفية مرتفع نسبياً؛ جرّب Adaptive Noise Control بحذر."
        if (r.spectralCentroidHz < 900) advice += "الصوت قد يكون مكتوماً؛ جرّب Smart Auto EQ ثم قارن النتيجة."
        if (r.spectralCentroidHz > 5000) advice += "الصوت غني بالترددات العالية؛ تجنب زيادة الـ Treble."
        if (advice.isEmpty()) advice += "المؤشرات الأساسية متوازنة. احتفظ بالأصل وقارن أي تعديل بمستوى صوت متطابق."
        return advice.joinToString("\n• ", prefix = "• ")
    }

    fun deviceReport(): DeviceReport {
        val activity = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        activity.getMemoryInfo(info)
        val used = (info.totalMem - info.availMem).coerceAtLeast(0) / (1024 * 1024)
        val total = info.totalMem / (1024 * 1024)
        val thermal = if (Build.VERSION.SDK_INT >= 29) {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "طبيعي"
                PowerManager.THERMAL_STATUS_LIGHT -> "خفيف"
                PowerManager.THERMAL_STATUS_MODERATE -> "متوسط"
                PowerManager.THERMAL_STATUS_SEVERE -> "مرتفع"
                PowerManager.THERMAL_STATUS_CRITICAL -> "حرج"
                PowerManager.THERMAL_STATUS_EMERGENCY -> "طوارئ"
                else -> "غير معروف"
            }
        } else "غير متاح على إصدار Android هذا"
        return DeviceReport(Runtime.getRuntime().availableProcessors(), used, total, thermal)
    }

    private fun spectralCentroid(samples: ShortArray, sampleRate: Int): Double {
        val n = min(1024, samples.size)
        if (n < 32) return 0.0
        var weighted = 0.0; var magnitudeSum = 0.0
        for (k in 1 until n / 2) {
            var re = 0.0; var im = 0.0
            for (i in 0 until n) {
                val window = 0.5 - 0.5 * cos(2.0 * PI * i / (n - 1))
                val v = samples[i] / 32768.0 * window
                val angle = 2.0 * PI * k * i / n
                re += v * cos(angle); im -= v * kotlin.math.sin(angle)
            }
            val mag = sqrt(re * re + im * im)
            val hz = k.toDouble() * sampleRate / n
            weighted += hz * mag; magnitudeSum += mag
        }
        return if (magnitudeSum <= 1e-12) 0.0 else weighted / magnitudeSum
    }

    private fun onePoleCoefficient(cutoff: Double, sampleRate: Int) = (1.0 - kotlin.math.exp(-2.0 * PI * cutoff / sampleRate)).toFloat()

    private fun writeResult(source: File, samples: ShortArray, suffix: String): File {
        val wav = requireMono(source)
        val out = File(context.getExternalFilesDir(null), "CV_${suffix}_${System.currentTimeMillis()}.wav")
        AdvancedAudioTools(context).writeWav(out, samples, wav.sampleRate, 1)
        return out
    }

    private fun Double.pow10(exp: Double): Double = kotlin.math.exp(exp * ln(10.0))
}
