package com.cybervoice.app

import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import java.io.File
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

internal val Bg = Color(0xFF070B12)
internal val Panel = Color(0xFF101A29)
internal val Panel2 = Color(0xFF142338)
internal val Cyan = Color(0xFF48DFFF)
internal val Muted = Color(0xFF8BA3B9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(7, 11, 18)
        window.navigationBarColor = android.graphics.Color.rgb(7, 11, 18)
        setContent { CyberVoiceApp() }
    }
}

private enum class Page(val label: String) {
    HOME("الرئيسية"), STUDIO("الاستوديو"), EFFECTS("المؤثرات"), FILES("ملفاتي"), LAB("المختبر")
}

@Composable
private fun CyberVoiceApp() {
    var page by remember { mutableStateOf(Page.HOME) }
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan,
            background = Bg,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0B121E), contentColor = Cyan) {
                    val entries = listOf(
                        Triple(Page.HOME, Icons.Default.GridView, "الرئيسية"),
                        Triple(Page.STUDIO, Icons.Default.GraphicEq, "الاستوديو"),
                        Triple(Page.EFFECTS, Icons.Default.Tune, "المؤثرات"),
                        Triple(Page.FILES, Icons.Default.FolderOpen, "ملفاتي"),
                        Triple(Page.LAB, Icons.Default.Science, "المختبر")
                    )
                    entries.forEach { (target, icon, label) ->
                        NavigationBarItem(
                            selected = page == target,
                            onClick = { page = target },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Cyan,
                                selectedTextColor = Cyan,
                                indicatorColor = Color(0xFF17364A),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (page) {
                    Page.HOME -> HomeScreen(
                        onStudio = { page = Page.STUDIO },
                        onEffects = { page = Page.EFFECTS },
                        onFiles = { page = Page.FILES }
                    )
                    Page.STUDIO -> StudioScreen()
                    Page.EFFECTS -> EffectsScreen()
                    Page.FILES -> FilesScreen()
                    Page.LAB -> AdvancedLabScreen()
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(onStudio: () -> Unit, onEffects: () -> Unit, onFiles: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 20.dp).padding(top = 24.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("CYBER", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                Text("VOICE  /  AUDIO LAB", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp)
            }
            Box(
                Modifier.size(42.dp).clip(CircleShape)
                    .background(Panel2).border(1.dp, Cyan.copy(alpha = .5f), CircleShape),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.Bolt, null, tint = Cyan) }
        }

        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF142B40), Color(0xFF0D1422), Color(0xFF101A29))))
                .border(1.dp, Cyan.copy(alpha = .35f), RoundedCornerShape(26.dp))
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("AUDIO CORE", color = Muted, fontSize = 10.sp, letterSpacing = 3.sp)
            Box(
                Modifier.size(116.dp).clip(CircleShape)
                    .background(Color(0xFF0A1725))
                    .border(1.5.dp, Cyan.copy(alpha = .75f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.GraphicEq, null, tint = Cyan, modifier = Modifier.size(58.dp))
            }
            Text("جاهز لتغيير الصوت", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text("VOICE ENGINE  •  STANDBY", color = Cyan, fontSize = 10.sp, letterSpacing = 1.5.sp)
            Button(
                onClick = onStudio,
                colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Icon(Icons.Default.Mic, null)
                Spacer(Modifier.width(8.dp))
                Text("افتح استوديو الصوت", fontWeight = FontWeight.Bold)
            }
        }

        Text("مركز التحكم", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            HomeTile("المؤثرات", "اختار شخصية صوتك", Icons.Default.Tune, Modifier.weight(1f), onEffects)
            HomeTile("ملفاتي", "التسجيلات المحفوظة", Icons.Default.Folder, Modifier.weight(1f), onFiles)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Info, null, tint = Cyan, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(8.dp))
            Text("Audio Lab متقدم • معالجة محلية وتسجيل وتحليل صوت", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun HomeTile(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(Panel)
            .border(1.dp, Color(0xFF24384C), RoundedCornerShape(18.dp))
            .clickable(onClick = onClick).padding(15.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(icon, null, tint = Cyan, modifier = Modifier.size(25.dp))
        Text(title, color = Color.White, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun StudioScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val engine = remember { AudioEngine(context) }
    var recording by remember { mutableStateOf(false) }
    var currentFile by remember { mutableStateOf<File?>(null) }
    var message by remember { mutableStateOf("محرك التسجيل جاهز — Natural DSP · 48 kHz / PCM16") }
    var preset by remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) { onDispose { engine.stopRecording() } }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            try { currentFile = engine.startRecording(preset); recording = true; message = "جاري التسجيل…" }
            catch (e: Exception) { message = "تعذر بدء التسجيل: ${e.message}" }
        } else message = "لازم تسمح باستخدام المايكروفون حتى يبدأ التسجيل"
    }
    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) try { currentFile = engine.importUri(uri); message = "تم استيراد الملف: ${currentFile?.name}" } catch (e: Exception) { message = "فشل الاستيراد: ${e.message}" }
    }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        ScreenHeading("VOICE STUDIO", "استوديو تسجيل وتعديل الصوت")
        Column(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(24.dp)).background(Panel).border(1.dp, Cyan.copy(alpha = .25f), RoundedCornerShape(24.dp)).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.GraphicEq, null, tint = Cyan, modifier = Modifier.size(30.dp))
                Spacer(Modifier.width(10.dp))
                Column { Text(if (recording) "LIVE RECORDING" else "AUDIO PROCESSOR", color = Cyan, fontSize = 11.sp, letterSpacing = 2.sp); Text(currentFile?.name ?: "ماكو ملف محدد", color = Color.White, fontWeight = FontWeight.Bold) }
            }
            Box(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(18.dp)).background(Color(0xFF09121E)), contentAlignment = Alignment.Center) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    repeat(34) { i ->
                        val h = listOf(12,22,36,18,48,28,16,40,55,23,34,15)[i % 12].dp
                        Box(Modifier.width(4.dp).height(if (recording) h else (h * .55f)).clip(CircleShape).background(Cyan.copy(alpha = if (recording) .9f else .42f)))
                    }
                }
            }
            Text(message, color = Muted, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = {
                    if (!recording) {
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            try { currentFile = engine.startRecording(preset); recording = true; message = "جاري التسجيل…" } catch (e: Exception) { message = "تعذر التسجيل: ${e.message}" }
                        } else permission.launch(Manifest.permission.RECORD_AUDIO)
                    } else {
                        currentFile = engine.stopRecording(); recording = false; message = "انحفظ التسجيل بصيغة WAV"
                    }
                }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (recording) Color(0xFF34465A) else Cyan, contentColor = if (recording) Color.White else Bg)) {
                    Icon(if (recording) Icons.Default.Stop else Icons.Default.Mic, null); Spacer(Modifier.width(6.dp)); Text(if (recording) "إيقاف وحفظ" else "تسجيل مباشر")
                }
                OutlinedButton(onClick = { importPicker.launch(arrayOf("audio/*")) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.FileOpen, null); Spacer(Modifier.width(5.dp)); Text("استيراد") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { currentFile?.let { try { engine.play(it); message = "جاري تشغيل الملف" } catch (e: Exception) { message = "تعذر التشغيل: ${e.message}" } } ?: run { message = "سجّل أو استورد ملف أولاً" } }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.PlayArrow, null); Text("تشغيل") }
                OutlinedButton(onClick = { currentFile?.let { try { val edited = engine.applyBasicDsp(it, preset); currentFile = edited; message = "تم تطبيق المعالجة وحفظ نسخة جديدة" } catch (e: Exception) { message = e.message ?: "تعذر تطبيق المؤثر" } } ?: run { message = "اختار ملف WAV أولاً" } }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.AutoFixHigh, null); Text("معالجة") }
            }
            Text("نوع المعالجة", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Natural", "Warm", "Bright", "Clear").forEachIndexed { index, name ->
                    FilterChip(selected = preset == index, onClick = { preset = index }, label = { Text(name, fontSize = 10.sp) })
                }
            }
        }
        Text("الاستيراد يقبل ملفات الصوت من مدير الملفات أو مجلد Telegram. المعالجة الحالية لملفات WAV PCM فقط.", color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun EffectsScreen() {
    val effects = listOf(
        "Deep Man" to "صوت عميق", "Female" to "تأثير أنثوي",
        "Robot" to "روبوت", "Alien" to "فضائي",
        "Radio" to "راديو", "Echo" to "صدى",
        "Monster" to "وحش", "Chipmunk" to "كرتوني"
    )
    var selected by remember { mutableStateOf("Deep Man") }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        ScreenHeading("VOICE EFFECTS", "مكتبة المؤثرات الصوتية")
        LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(effects) { item ->
                val active = selected == item.first
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                        .background(if (active) Color(0xFF123044) else Panel)
                        .border(1.dp, if (active) Cyan else Color(0xFF26384A), RoundedCornerShape(18.dp))
                        .clickable { selected = item.first }.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(Icons.Default.GraphicEq, null, tint = Cyan, modifier = Modifier.size(28.dp))
                    Text(item.first, color = Color.White, fontWeight = FontWeight.Bold)
                    Text(item.second, color = Muted, fontSize = 11.sp)
                    if (active) Text("محدد", color = Cyan, fontSize = 10.sp)
                }
            }
        }
        Text("اختيار المؤثر حالياً واجهة تجريبية؛ المعالجة الفعلية ستضاف بمحرك الصوت.", color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun FilesScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val engine = remember { AudioEngine(context) }
    var refresh by remember { mutableIntStateOf(0) }
    val files = remember(refresh) { engine.listAudio() }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { ScreenHeading("MY AUDIO", "تسجيلاتك وملفاتك") }
            IconButton(onClick = { refresh++ }) { Icon(Icons.Default.Refresh, null, tint = Cyan) }
        }
        if (files.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(22.dp)).background(Panel).border(1.dp, Color(0xFF26384A), RoundedCornerShape(22.dp)).padding(20.dp), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(Icons.Default.FolderOpen, null, tint = Cyan, modifier = Modifier.size(54.dp))
                    Text("ماكو ملفات محفوظة حالياً", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("سجّل صوت أو استورد ملف من الاستوديو", color = Muted, fontSize = 11.sp)
                }
            }
        } else {
            androidx.compose.foundation.lazy.LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(files) { file ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Panel).border(1.dp, Color(0xFF26384A), RoundedCornerShape(15.dp)).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AudioFile, null, tint = Cyan)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) { Text(file.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold); Text("${file.extension.uppercase()} • ${file.length() / 1024} KB", color = Muted, fontSize = 10.sp) }
                        IconButton(onClick = { try { engine.play(file) } catch (_: Exception) {} }) { Icon(Icons.Default.PlayArrow, null, tint = Cyan) }
                    }
                }
            }
        }
    }
}

@Composable
internal fun ScreenHeading(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(title, color = Cyan, fontSize = 11.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
    }
}
