#include <jni.h>
#include <oboe/Oboe.h>
#include <android/log.h>
#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <memory>
#include <mutex>
#include <vector>

namespace {
constexpr int32_t kRequestedRate = 48000;
constexpr size_t kRingCapacity = 96000; // 2 seconds at 48 kHz

struct DspState {
    float low = 0.0f;
    float envelope = 0.0f;
    float gateGain = 1.0f;
};

// Shared DSP implementation used by both file/recorder processing and Oboe Live.
inline void processBlock(float* x, int32_t count, int preset, DspState& state) {
    if (!x || count <= 0) return;
    const float lowCoeff = 0.025f; // gentle low-frequency tracking
    for (int32_t i = 0; i < count; ++i) {
        float v = x[i];
        state.low += lowCoeff * (v - state.low);
        const float low = state.low;
        const float high = v - low;

        // Gentle adaptive expander. It attenuates very low-level room noise without
        // hard-gating speech tails. It is deliberately conservative for natural speech.
        const float level = std::fabs(v);
        const float targetGate = level < 0.006f ? 0.72f + 0.28f * (level / 0.006f) : 1.0f;
        const float gateCoeff = targetGate < state.gateGain ? 0.025f : 0.004f;
        state.gateGain += gateCoeff * (targetGate - state.gateGain);
        v *= state.gateGain;

        // Preset 0 is neutral/natural. Other profiles apply restrained tonal changes.
        if (preset == 1) v = low * 1.08f + high * 0.94f;       // Warm
        else if (preset == 2) v = low * 0.96f + high * 1.06f;  // Bright
        else if (preset == 3) v = low * 0.94f + high * 1.08f;  // Clear

        // Smooth speech compressor with modest ratio and slow envelope.
        const float a = std::fabs(v);
        state.envelope = 0.996f * state.envelope + 0.004f * a;
        if (state.envelope > 0.55f) {
            const float desired = 0.55f + (state.envelope - 0.55f) * 0.45f;
            v *= desired / state.envelope;
        }
        // Soft saturation guard; hard clipping is avoided.
        const float drive = v * 1.015f;
        x[i] = std::tanh(drive * 1.03f) / 1.03f;
    }
}

class CyberOboeEngine final : public oboe::AudioStreamDataCallback {
public:
    CyberOboeEngine() : ring_(kRingCapacity, 0.0f) {}

    oboe::Result start(int preset) {
        preset_.store(preset);
        oboe::AudioStreamBuilder inBuilder;
        inBuilder.setDirection(oboe::Direction::Input)
                 ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
                 ->setSharingMode(oboe::SharingMode::Shared)
                 ->setFormat(oboe::AudioFormat::Float)
                 ->setFormatConversionAllowed(true)
                 ->setChannelCount(1)
                 ->setSampleRate(kRequestedRate)
                 ->setInputPreset(oboe::InputPreset::VoiceRecognition)
                 ->setPackageName("com.cybervoice.app")
                 ->setDataCallback(this);
        auto result = inBuilder.openStream(input_);
        if (result != oboe::Result::OK || !input_) return result;

        oboe::AudioStreamBuilder outBuilder;
        outBuilder.setDirection(oboe::Direction::Output)
                  ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
                  ->setSharingMode(oboe::SharingMode::Shared)
                  ->setFormat(oboe::AudioFormat::Float)
                  ->setFormatConversionAllowed(true)
                  ->setChannelCount(1)
                  ->setSampleRate(input_->getSampleRate())
                  ->setUsage(oboe::Usage::Media)
                  ->setContentType(oboe::ContentType::Speech)
                  ->setDataCallback(this);
        result = outBuilder.openStream(output_);
        if (result != oboe::Result::OK || !output_) {
            input_->close(); input_.reset(); return result;
        }

        const int32_t outBurst = std::max(1, output_->getFramesPerBurst());
        output_->setBufferSizeInFrames(outBurst * 2);
        readIndex_.store(0);
        writeIndex_.store(0);
        underruns_.store(0);
        inputState_ = DspState{};
        outputState_ = DspState{};
        result = input_->requestStart();
        if (result != oboe::Result::OK) { closeStreams(); return result; }
        result = output_->requestStart();
        if (result != oboe::Result::OK) { closeStreams(); return result; }
        running_.store(true);
        return oboe::Result::OK;
    }

    void setPreset(int preset) { preset_.store(preset); }

    void stop() {
        running_.store(false);
        closeStreams();
    }

    oboe::DataCallbackResult onAudioReady(oboe::AudioStream* stream, void* audioData, int32_t numFrames) override {
        if (stream == input_.get()) {
            const auto* in = static_cast<const float*>(audioData);
            const int32_t channels = std::max(1, stream->getChannelCount());
            uint64_t w = writeIndex_.load(std::memory_order_relaxed);
            const uint64_t r = readIndex_.load(std::memory_order_acquire);
            for (int32_t frame = 0; frame < numFrames; ++frame) {
                if (w - r >= kRingCapacity) break; // drop newest on overflow; never block callback
                float mono = 0.0f;
                for (int32_t ch = 0; ch < channels; ++ch) mono += in[frame * channels + ch];
                mono /= static_cast<float>(channels);
                ring_[w % kRingCapacity] = mono;
                ++w;
            }
            writeIndex_.store(w, std::memory_order_release);
            return oboe::DataCallbackResult::Continue;
        }

        auto* out = static_cast<float*>(audioData);
        const int32_t channels = std::max(1, stream->getChannelCount());
        uint64_t r = readIndex_.load(std::memory_order_relaxed);
        const uint64_t w = writeIndex_.load(std::memory_order_acquire);
        const int32_t available = static_cast<int32_t>(std::min<uint64_t>(w - r, static_cast<uint64_t>(numFrames)));
        for (int32_t frame = 0; frame < numFrames; ++frame) {
            float sample = 0.0f;
            if (frame < available) sample = ring_[(r++) % kRingCapacity];
            else underruns_.fetch_add(1, std::memory_order_relaxed);
            out[frame * channels] = sample;
            for (int32_t ch = 1; ch < channels; ++ch) out[frame * channels + ch] = sample;
        }
        readIndex_.store(r, std::memory_order_release);
        processBlock(out, numFrames * channels, preset_.load(), outputState_);
        return oboe::DataCallbackResult::Continue;
    }

    jfloatArray metrics(JNIEnv* env) {
        int32_t xrunCount = 0;
        if (output_) {
            auto xrunResult = output_->getXRunCount();
            if (xrunResult) xrunCount = xrunResult.value();
        }
        jfloat values[5] = {
            static_cast<float>(output_ ? output_->getSampleRate() : 0),
            static_cast<float>(input_ ? input_->getFramesPerBurst() : 0),
            static_cast<float>(output_ ? output_->getFramesPerBurst() : 0),
            static_cast<float>(underruns_.load()),
            static_cast<float>(xrunCount)
        };
        jfloatArray arr = env->NewFloatArray(5);
        if (arr) env->SetFloatArrayRegion(arr, 0, 5, values);
        return arr;
    }

private:
    void closeStreams() {
        if (output_) { output_->requestStop(); output_->close(); output_.reset(); }
        if (input_) { input_->requestStop(); input_->close(); input_.reset(); }
    }

    std::shared_ptr<oboe::AudioStream> input_;
    std::shared_ptr<oboe::AudioStream> output_;
    std::vector<float> ring_;
    std::atomic<uint64_t> writeIndex_{0};
    std::atomic<uint64_t> readIndex_{0};
    std::atomic<int> preset_{0};
    std::atomic<uint64_t> underruns_{0};
    std::atomic<bool> running_{false};
    DspState inputState_{};
    DspState outputState_{};
};

std::mutex gEngineMutex;
std::unique_ptr<CyberOboeEngine> gEngine;
std::mutex gOfflineMutex;
DspState gOfflineState{};
}

extern "C" JNIEXPORT void JNICALL
Java_com_cybervoice_app_AudioEngine_nativeProcess(JNIEnv* env, jobject, jfloatArray array, jint preset) {
    const jsize n = env->GetArrayLength(array);
    jfloat* x = env->GetFloatArrayElements(array, nullptr);
    if (!x) return;
    {
        std::lock_guard<std::mutex> lock(gOfflineMutex);
        processBlock(x, n, preset, gOfflineState);
    }
    env->ReleaseFloatArrayElements(array, x, 0);
}

extern "C" JNIEXPORT void JNICALL
Java_com_cybervoice_app_AudioEngine_nativeResetProcessing(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(gOfflineMutex);
    gOfflineState = DspState{};
}

extern "C" JNIEXPORT jint JNICALL
Java_com_cybervoice_app_AudioEngine_nativeStartOboe(JNIEnv*, jobject, jint preset) {
    std::lock_guard<std::mutex> lock(gEngineMutex);
    if (gEngine) return static_cast<jint>(oboe::Result::OK);
    auto engine = std::make_unique<CyberOboeEngine>();
    const auto result = engine->start(preset);
    if (result == oboe::Result::OK) gEngine = std::move(engine);
    return static_cast<jint>(result);
}

extern "C" JNIEXPORT void JNICALL
Java_com_cybervoice_app_AudioEngine_nativeStopOboe(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(gEngineMutex);
    if (gEngine) { gEngine->stop(); gEngine.reset(); }
}

extern "C" JNIEXPORT void JNICALL
Java_com_cybervoice_app_AudioEngine_nativeSetOboePreset(JNIEnv*, jobject, jint preset) {
    std::lock_guard<std::mutex> lock(gEngineMutex);
    if (gEngine) {
        gEngine->setPreset(preset);
    }
}

extern "C" JNIEXPORT jfloatArray JNICALL
Java_com_cybervoice_app_AudioEngine_nativeOboeMetrics(JNIEnv* env, jobject) {
    std::lock_guard<std::mutex> lock(gEngineMutex);
    if (!gEngine) return env->NewFloatArray(0);
    return gEngine->metrics(env);
}
