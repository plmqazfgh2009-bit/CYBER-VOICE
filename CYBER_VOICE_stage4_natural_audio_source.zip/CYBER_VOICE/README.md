# CYBER VOICE — Stage 4 Natural Audio

A native Android/Kotlin + Jetpack Compose audio project with a dark/cyan interface.

## Stage 4 work included in this source package

- Native Oboe full-duplex Live path: Oboe input and output streams, low-latency performance mode, callback-to-callback PCM ring buffer, and native DSP in the output callback.
- Shared C++ DSP routine used by Oboe Live, microphone recording chunks, and offline WAV processing.
- Natural / Warm / Bright / Clear restrained voice profiles.
- WAV Naturalness Analyzer: duration, sample rate, RMS dBFS, sample peak, linearly oversampled true-peak estimate, clipping percentage, estimated quiet-block noise floor, crest factor, and spectral centroid.
- Smart Auto EQ: conservative three-band tonal correction, limited to a restrained gain range.
- Adaptive Noise Control: adaptive expander/gate based on low-energy blocks. This is conventional DSP, not neural source separation.
- Loudness Intelligence: RMS dBFS normalization with a sample-peak ceiling. It is intentionally labelled dBFS, not LUFS.
- Advanced Audio Repair: conservative interpolation of isolated single-sample impulses. It cannot reconstruct heavily clipped audio.
- Reference Comparison: compare RMS, sample peak, and spectral centroid for two user-supplied WAV files.
- CYBER AI Assistant: transparent rule-based recommendations from measured audio properties. No neural AI model is bundled in this build.
- Device Optimization diagnostics: CPU core count, device memory status, and Android thermal status.
- Undo/Redo snapshots, named presets/profiles, and saved RMS target setting.
- Existing Stage 3 lab tools remain in the project.

## Important implementation boundaries

- Oboe is now used for the Live microphone-to-output path. Actual performance, route changes, underruns, and latency must still be validated on physical devices.
- Microphone file recording uses Android AudioRecord for broad compatibility, then passes captured blocks through the same native C++ DSP routine used by Oboe Live and offline processing.
- Current advanced file-processing actions require mono PCM16 WAV. Imported compressed formats can be stored/shared, but these DSP tools do not decode every compressed format.
- The true-peak value is a 4x linear-interpolation estimate, not a standards-certified oversampled meter.
- Loudness normalization uses RMS dBFS; EBU/ITU integrated LUFS measurement and true-peak limiting are not implemented.
- Adaptive noise control is a conservative expander/gate, not neural denoising.
- CYBER AI Assistant is rule-based, not a generative/neural model.
- WebRTC calling, saved-file neural transcription, neural vocal isolation, and neural voice conversion are not implemented.
- Android generally does not allow an ordinary app to inject processed microphone audio into arbitrary third-party calls or cellular calls.

## Build requirements

- Android Studio with Android Gradle Plugin 8.13.2 support
- JDK 17
- Android SDK Platform 36
- Android NDK 27.2.12479018
- CMake 3.22.1
- Internet access for Gradle/Maven dependencies on the first sync

Open the `CYBER_VOICE` folder in Android Studio, allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Validation status for this delivery

- Kotlin `NaturalAudioProcessor.kt` compiled independently against lightweight Android/API stubs.
- Source structure and XML/ZIP integrity are checked separately before packaging.
- A full Android Gradle build was **not** run in the current environment because Gradle, Android SDK, and NDK are not installed and network access is unavailable.
- No APK has been produced or installed here.
- No physical POCO F7 test has been performed here. Oboe Live must be tested on the phone with headphones, and the Oboe diagnostics screen should be checked for underruns/Xruns during longer sessions.

Do not treat the source package as a device-certified release until those final build and device tests pass.
